package br.com.uscsitau.uscsitau;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UscsitauApplicationTests {

	@Test
	void contextLoads() {
	}

}
