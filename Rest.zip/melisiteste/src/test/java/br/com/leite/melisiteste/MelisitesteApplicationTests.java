package br.com.leite.melisiteste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MelisitesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
