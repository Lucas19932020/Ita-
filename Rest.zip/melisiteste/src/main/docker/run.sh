#!/bin/sh
echo "************************************************************"
echo "Starting Template Server with Docker "
echo "************************************************************"

java -jar /usr/local/dockerize/@project.build.finalName@.jar
