package br.com.uscs.demo.uscsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UscsdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
